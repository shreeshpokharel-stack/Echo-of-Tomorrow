# Echoes of Tomorrow — Temporal Puzzle Adventure

## Core Idea
Bridge two linked timelines side-by-side in real time:
- **Sunlit Past (2089)** vs **Night Future (2189)**.
- Actions in 2089 (unlocking Ancient Keys & Temporal Doors, powering generators, collapsing bridges) reshape 2189.

## Controls
- **A / D** or **Arrow Left / Right**: Move
- **Space / W**: Jump
- **Shift / C**: 20-Second Chrono Wings Flight
- **J** or **Left Click**: Elemental Attack (Fire / Water / Earth)
- **K**: 20-Second Elemental Overdrive
- **V**: Summon Equipped 20-Second Armory Car / Vehicle
- **E**: Interact (Keys, Doors, Conduits, Generators)
- **Q**: Chrono Shift (2089 <-> 2189)
- **F**: Temporal Freeze (5s)
- **M / N**: Mute Audio / Toggle Music
- **P / Esc**: Pause

## Save Snapshot Summary
- **Chrono Coins**: 4903
- **Selected Champion**: WATER
- **Owned Armory Cards**: 2
- **Achievements Unlocked**: 8
